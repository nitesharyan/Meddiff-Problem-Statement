﻿using System;
using System.Collections.Generic;

namespace FileOwners
{
	class Program
	{
		static void Main(string[] args)
		{
			Console.WriteLine("Hello World!");
			Dictionary<string, string> ownersByFile = new Dictionary<string, string>()
			{
				{ "Input.txt", "Randy" },
				{ "Code.py", "Stan" }, 
				{ "Output.txt", "Randy"}
			};
			var fileByOwners = new Program().GroupByOwners(ownersByFile);
            foreach (var item in fileByOwners)
            {
				Console.WriteLine($"{item.Key}: {string.Join(",", item.Value)}");
            }
		}

		/// <summary>
		/// Groups the data based on Owner name and return a new dictionary
		/// </summary>
		/// <param name = "ownersByFile"> Dictionary of data where it is sorted by file name </param>
		/// <returns> Dictionary where the data is based on Owner name </returns>
		private Dictionary<string, List<string>> GroupByOwners(Dictionary<string, string> ownersByFile)
		{
			Dictionary<string, List<string>> fileByOwners = new Dictionary<string, List<string>>();
			foreach (var item in ownersByFile)
			{
				if (fileByOwners.ContainsKey(item.Key))
				{
					fileByOwners[item.Value].Add(item.Key);
					continue;
				}
				fileByOwners.TryAdd(item.Value, new List<string>() { item.Key });
			}

			return fileByOwners;
		}
	}
}
