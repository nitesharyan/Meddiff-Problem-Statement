﻿using System;

namespace PalindromeCheck
{
    class Program
    {
        /// <summary>
        /// Main or startup function
        /// </summary>
        /// <param name="args"></param>
        static void Main(string[] args)
        {
            Console.Write("Enter you string: ");
            string word = Console.ReadLine();
            if (new Program().IsPalindrome(word))
            {
                Console.Write("Given String is palindrome");
            }
            else
            {
                Console.Write("Given String is not a palindrome");
            }
        }

        /// <summary>
        /// Returns a boolean value if a given string is palindrome or not (Case insensitively)
        /// </summary>
        /// <param name = "word"> String to be checked </param>
        /// <returns> Boolean value for is boolean or not </returns>
        private bool IsPalindrome(string word)
        {
            char[] wordToArray = word.ToCharArray();
            Array.Reverse(wordToArray);
            string reversedWord = string.Join("", wordToArray);
            return reversedWord.Equals(word, StringComparison.InvariantCultureIgnoreCase);
        }
    }
}
